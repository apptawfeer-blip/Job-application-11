---
name: "prompt-upgrader"
description: "Turn a short or rough prompt into a professional, well-structured prompt for Claude using Anthropic's prompting best practices. Use when asked to improve, rewrite, upgrade or professionalize a prompt."
---

# Prompt Upgrader

Convert a simple prompt into a professional one, following Anthropic's "Prompting best practices" guide (https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/claude-prompting-best-practices).

## Workflow

1. **Read the input prompt** and identify: the task, the audience, the desired output, and where it will run (chat, system prompt, API call, agent/coding harness).
2. **Find the gaps.** Apply the *colleague test*: would a smart person with no context know exactly what to do? List what is missing (goal, context, constraints, format, length, examples, success criteria).
3. **Fill gaps sensibly.** If a missing detail would change the result a lot and can't be reasonably assumed, ask the user at most 2–3 short questions. Otherwise make a sensible assumption, mark it with a `[placeholder]` the user can edit, and continue.
4. **Rewrite** using the techniques below. Only include sections that earn their place — a one-line task does not need ten XML blocks.
5. **Deliver** in the output format below.

## Techniques to apply

**Clear and direct**
- State the task explicitly. If you want more than the literal task, ask for it ("Go beyond the basics… include as many relevant features as possible").
- Use action verbs when action is wanted: "Change this function to…" not "Can you suggest changes…".
- Use numbered steps when order or completeness matters.

**Context and motivation**
- Explain *why* each important rule exists; Claude generalizes from the reason. E.g. instead of "NEVER use ellipses" → "This will be read aloud by a text-to-speech engine, so don't use ellipses, which it can't pronounce."
- Give background: who the output is for, what it will be used for, what good looks like.

**Role**
- Add one sentence of role when it helps focus tone and expertise ("You are a senior data analyst specializing in retail sales."). Put it in the system prompt if the prompt is for the API.

**XML structure**
- Separate parts with consistent, descriptive tags: `<context>`, `<instructions>`, `<input>`, `<examples>`/`<example>`, `<output_format>`, `<constraints>`.
- Nest for hierarchy, e.g. `<documents><document index="1"><source>…</source><document_content>…</document_content></document></documents>`.

**Examples (few-shot)**
- When format, tone or structure matters, include 3–5 examples in `<examples>` tags: relevant to the real use case, diverse (cover edge cases), and not so similar that they create unintended patterns. If none are given, add placeholders and tell the user to fill them.

**Long context (20k+ tokens of material)**
- Put the long documents at the **top**, the instructions and question at the **end**.
- Ask Claude to first extract relevant quotes (e.g. in `<quotes>` tags), then answer from them.

**Output format**
- Say what to do, not what to avoid ("Write in flowing prose paragraphs" rather than "Don't use markdown").
- Specify length, structure, language, and any tags for the answer (e.g. `<answer>`).
- Match the prompt's own style to the desired output (a prose prompt yields more prose).
- If plain text math is needed, say so explicitly (no LaTeX).

**Reasoning**
- For multi-step problems, prefer a general instruction ("Think this through carefully before answering") over a hand-written plan.
- Add a self-check where it matters: "Before finishing, verify your answer against [criteria]."
- For research tasks: define success criteria, ask for verification across multiple sources, and for competing hypotheses with confidence levels.

**Agentic / tool-use prompts** (only when the prompt drives an agent or coding tool)
- Choose a default: act (`<default_to_action>` – implement rather than suggest) or be conservative (`<do_not_act_before_instructions>`).
- Encourage parallel tool calls for independent actions; never guess missing parameters.
- Add a reversibility rule: local reversible actions are fine; ask before destructive, shared or external actions (rm -rf, force-push, sending messages).
- Counter over-engineering: only make requested or clearly necessary changes; no extra features, abstractions or files; clean up temporary files.
- Ground answers: never speculate about code or files not opened; read first.
- Ask for general solutions, not hard-coded values to pass tests; report bad tests instead of working around them.
- For long tasks: track state in files (JSON for structured status, text for notes, git for checkpoints) and work incrementally.

**Frontend / design prompts**
- Ask for distinctive typography, a cohesive palette with CSS variables, purposeful motion, and layered backgrounds; explicitly avoid generic defaults (Inter/Arial, purple-gradient-on-white, cookie-cutter layouts). Ask explicitly for animations and interactivity if wanted.

## Tone rules for the rewritten prompt
- Calm, plain language. Avoid shouting ("CRITICAL: You MUST…"); modern Claude models over-react to it. Write "Use this tool when…".
- Avoid blanket anti-laziness lines ("be thorough", "if in doubt, use the tool") — they cause over-triggering. Be targeted instead.
- Don't rely on prefilled assistant turns; put format control in instructions.
- Keep the user's language (e.g. if the original prompt is in Arabic, write the professional version in Arabic unless asked otherwise). Keep tag names in English.

## Output format

Reply with exactly these parts:

1. **Improved prompt** — in one fenced code block, ready to copy. If it is meant for the API, split it into `System prompt` and `User message` blocks.
2. **What changed** — 3–6 short bullets naming the techniques applied and why.
3. **Fill in** — list any `[placeholders]` the user should complete (only if there are any).

## Example

**Input:** `write a blog post about remote work`

**Improved prompt:**
```
You are an experienced workplace-culture writer.

<context>
This post is for [our company blog], read mainly by [mid-level managers in tech companies]. The goal is to give them practical ideas they can apply with their teams this month, not general opinions.
</context>

<instructions>
Write a blog post about leading remote teams well.
1. Open with a short, concrete scenario a manager will recognize.
2. Cover 4–5 practical practices (e.g. async communication, meeting hygiene, building trust, measuring outcomes), each with a specific example.
3. Close with a short checklist readers can use this week.
</instructions>

<output_format>
- Length: about 900–1,100 words.
- A title, short section headings, and flowing paragraphs; use a list only for the final checklist.
- Warm, confident, jargon-free tone.
</output_format>

Before finishing, check that every practice includes a concrete example a manager could act on.
```

**What changed:** added a role; gave audience and purpose (context + motivation); broke the task into ordered steps; specified length, structure and tone; added a self-check.

**Fill in:** blog name, target audience.